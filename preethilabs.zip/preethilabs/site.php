<?php
     $xml=simplexml_load_file("xml/BILLINGTESTS.xml");
     $grptest_xml=simplexml_load_file("xml/GROUPTESTS.xml");

     $biochemistry_indiv  = $xml->xpath('Tests[specimen_id=1][Billgrp="T"]');
     $biochemistry_grp  = $xml->xpath('Tests[specimen_id=1][Billgrp="G"]');

     $pathology_indiv  = $xml->xpath('Tests[specimen_id=3][Billgrp="T"]');
     $pathology_grp  = $xml->xpath('Tests[specimen_id=3][Billgrp="G"]');

     $hematology_indiv  = $xml->xpath('Tests[specimen_id=5][Billgrp="T"]');
     $hematology_grp  = $xml->xpath('Tests[specimen_id=5][Billgrp="G"]');

     $microbiology_indiv  = $xml->xpath('Tests[specimen_id=6][Billgrp="T"]');
     $microbiology_grp  = $xml->xpath('Tests[specimen_id=6][Billgrp="G"]');

     $mxtest_indiv  = $xml->xpath('Tests[specimen_id=7][Billgrp="T"]');
     $mxtest_grp  = $xml->xpath('Tests[specimen_id=7][Billgrp="G"]');

     $semen_analysis_indiv  = $xml->xpath('Tests[specimen_id=8][Billgrp="T"]');
     $semen_analysis_grp  = $xml->xpath('Tests[specimen_id=8][Billgrp="G"]');

     $serology_indiv  = $xml->xpath('Tests[specimen_id=9][Billgrp="T"]');
     $serology_grp  = $xml->xpath('Tests[specimen_id=9][Billgrp="G"]');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com -->
  <title>Bootstrap Theme Company Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="css/fonts.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
  <link rel="stylesheet" type="text/css" href="css/custom.css " />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="js/easyResponsiveTabs.js"></script>
  
  <style>
    
  
  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage"><img src="images/logo2.jpg" width="200px" height="70px"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#about">ABOUT</a></li>
        <li><a href="#services">SERVICES</a></li>
        <li><a href="#portfolio">PORTFOLIO</a></li>
        <li><a href="#pricing">PRICING</a></li>
        <li><a href="#contact">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="images/person-holding-glass-flasks.jpg" alt="Los Angeles">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>LA is always so much fun!</p>
      </div>
    </div>

    <div class="item">
      <img src="images/scientist-using-microscope.jpg" alt="Chicago">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>LA is always so much fun!</p>
      </div>
    </div>

    <div class="item">
      <img src="images/person-holding-glass-flasks.jpg" alt="New York">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>LA is always so much fun!</p>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-8">
      <h2>About Us</h2><br>
      <h4>PREETHI Medical Laboratory established in Aluva 1980 and posses excellent track record in Laboratory Service.</h4><br>
      <br><button class="btn btn-default btn-lg"><a href="#contact">Get in Touch</a></button>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
</div>

<div class="container-fluid bg-grey">
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-globe logo slideanim"></span>
    </div>
    <div class="col-sm-8">
      <h2>Our Values</h2>
      <p>Quality Integrity Innovation Accountability</p>
      <h4><strong>MISSION:</strong> We aims at providing most relaible and accurate laboratory service.</h4><br>
      <h4><strong>VISION:</strong> Our vision is to be the laboratory service provider by providing to needy at the most affordable rates.</h4>
    </div>
  </div>
</div>

<!-- Container (Services Section) -->
<div id="services" class="container-fluid text-center">
  <h2>SERVICES</h2>
  <h4>What we offer</h4>
  <br>
  <div class="row slideanim">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-off logo-small"></span>
      <h4>POWER</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-heart logo-small"></span>
      <h4>LOVE</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-lock logo-small"></span>
      <h4>JOB DONE</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
  </div>
  <br><br>
  <div class="row slideanim">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-leaf logo-small"></span>
      <h4>GREEN</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-certificate logo-small"></span>
      <h4>CERTIFIED</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-wrench logo-small"></span>
      <h4 style="color:#303030;">HARD WORK</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
  </div>
</div>

<!-- Container (Portfolio Section) -->
<div id="portfolio" class="container-fluid text-center bg-grey">

  <h2>What our customers say</h2>
  <div id="myCarousel" class="carousel slide text-center" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <h4>"This company is the best. I am so happy with the result!"<br><span>Michael Roe, Vice President, Comment Box</span></h4>
      </div>
      <div class="item">
        <h4>"One word... WOW!!"<br><span>John Doe, Salesman, Rep Inc</span></h4>
      </div>
      <div class="item">
        <h4>"Could I... BE any more happy with this company?"<br><span>Chandler Bing, Actor, FriendsAlot</span></h4>
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<!-- Container (Pricing Section) -->
<div id="pricing" class="container-fluid bg-grey">
  <div class="text-center">
    <h2>Pricing</h2>
    <h4>Choose a payment plan that works for you</h4>
  </div>
  <div class="row slideanim">
    <div class="col-sm-4 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1 class="price_headings">Senior Citizen Male Checkup</h1>
        </div>
        <div class="panel-body">
          <p><strong>CBC & ESR</strong></p>
          <p><strong>BLOOD SUGAR FASTING</strong></p>
          <p><strong>SERUM CREATNINE</strong></p>
          <p><strong>CHOLESTROL TOTAL</strong></p>
          <p><strong>URIC ACID</strong></p>
          <p><strong>LIVER FUNCTION TEST</strong></p>
          <p><strong>PSA</strong></p>
        <div class="panel-footer">
          <h3>&#8377; 1000</h3>
          <button class="btn btn-lg">BOOK NOW</button>
        </div>
      </div>      
    </div> 
    </div>    
    <div class="col-sm-4 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1 class="price_headings">Daibetic Checkup</h1>
        </div>
        <div class="panel-body">
          <p><strong>BLOOD SUGAR</strong></p>
          <p><strong>BLOOD SUGAR</strong></p>
          <p><strong>HBAIC</strong></p>
          <p><strong>SERIUM CREATININE</strong></p>
          <p><strong>SGOT</strong></p>
          <p><strong>SGPT</strong></p>
          <p><strong>URINE MICRO ALBUMIN</strong></p>
        </div>
        <div class="panel-footer">
          <h3>&#8377; 750</h3>
          <button class="btn btn-lg">BOOK NOW</button>
        </div>
      </div>      
    </div>   
    <div class="col-sm-4 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1 class="price_headings">Mini Health Checkup</h1>
        </div>
        <div class="panel-body">
          <p><strong>CBC & ESR</strong> </p>
          <p><strong>RANDOME BLOOD SUGAR</strong> </p>
          <p><strong>CHOLESTROL</strong> </p>
          <p><strong>BILRUBIN TOTAL</strong> </p>
          <p><strong>CREATININE</strong> </p>
          <p><strong>URINE RE</strong> </p>
          <p>&nbsp;</p>
        </div>
        <div class="panel-footer">
          <h3>&#8377; 400</h3>
          <button class="btn btn-lg">BOOK NOW</button>
        </div>
      </div>      
    </div>     
     
  </div> 
  <div class="row slideanim">
    <div class="col-sm-4 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1 class="price_headings">Well Women Health Checkup</h1>
        </div>
        <div class="panel-body">
          <p><strong>CBC & ESR</strong> </p>
          <p><strong>FASTING BLOOD SUGAR</strong> </p>
          <p><strong>CALCIUM</strong> </p>
          <p><strong>THYROID FUNCTION TESTS</strong> </p>
          <p><strong>T3,T4,TSH</strong> </p>
          <p><strong>LIPID PROFILE</strong> </p>
          <p><strong>CHOLESTROL</strong> </p>
          <p><strong>TRIGLYCERIDES</strong> </p>
          <p><strong>HDL</strong> </p>
          <p><strong>LDL</strong> </p>
          <p><strong>VLDL</strong> </p>
          <p><strong>CREATININE</strong> </p>
          <p><strong>SGOT</strong> </p>
          <p><strong>SGPT</strong> </p>
          <p><strong>URINE ROUTINE</strong> </p>
        </div>
        <div class="panel-footer">
          <h3>&#8377; 900</h3>
          <button class="btn btn-lg">BOOK NOW</button>
        </div>
      </div>      
    </div> 
    <div class="col-sm-8 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1 class="price_headings">General Health Checkup</h1>
        </div>
        <div class="panel-body">
            <p>CBC & ESR</p>
            <p>FASTING BLOOD SUGAR</p>
            <div class="col-sm-4">
            <p><strong>LIPID PROFILE</strong></p>
            <p>CHOLESTEROL</p>
            <p>TRIGLYCERIDES</p>
            <p>HDL</p>
            <p>LDL</p>
            <p>VLDL</p>
          </div>
          <div class="col-sm-4">
            <p><strong>LIVER FUNCTION TEST</strong></p>
            <p>BILRUBIN(TOTAL)</p>
            <p>BILRUBIN(DIRECT)</p>
            <p>SGOT</p>
            <p>SGPT</p>
            <p>ALK.PHOSPHATE</p>
            <p>TOTAL PROTIEN</p>
            <p>ALBUMIN</p>
            <p>GLOBULIN</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
          </div>  
          <div class="col-sm-4">
            <p><strong>KIDNEY FUNCTION TEST</strong></p>
            <p>UREA</p>
            <p>CREATININE</p>
            <p>URINE RE</p>
            <p>HBA1C</p>
          </div>
        </div>
        <div class="panel-footer">
          <h3>&#8377; 1000</h3>
          <button class="btn btn-lg">BOOK NOW</button>
        </div>
      </div>      
    </div>   
  </div>
</div>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center">CONTACT</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Chicago, US</p>
      <p><span class="glyphicon glyphicon-phone"></span> +00 1515151515</p>
      <p><span class="glyphicon glyphicon-envelope"></span> myemail@something.com</p>
    </div>
    <div class="col-sm-7 slideanim">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="phone" name="phone" placeholder="Mobile" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="pincode" name="pincode" placeholder="Pincode" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="Address" name="Address" placeholder="Address" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button type="button" class="btn btn-info btn-lg" style="width: 100%;" data-toggle="modal" data-target="#myModal">Click here to select tests required.</button>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12 form-group">
          <ul class="cart" id="mycart">
            <li style="text-align:center">My Bookings</li>
            <li id="empty" style="text-align:center;background-color:white;color:grey;">--------------------------- Empty -----------------------</li>
          </ul>
        </div>
      </div>
      
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Send Enquiry</button>
        </div>
      </div>
    </div>
  </div>

</div>

<div class="modal fade" id="myModal" role="dialog" style="top: 5%;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <div id="container">
          <div id="parentHorizontalTab">
            <ul class="resp-tabs-list hor_1">
                <li>BIOCHEMISTRY</li>
                <li>CLINICAL PATHOLOGY</li>
                <li>HEMATOLOGY</li>
                <li>MICROBIOLOGY</li>
                <li>MX-TEST</li>
                <li>SEMEN ANALYSIS</li>
                <li>SEROLOGY</li>

            </ul>
            <div class="resp-tabs-container hor_1">
                <div>
                    <p>
                        <!--vertical Tabs-->
                        <div id="ChildVerticalTab_1">
                            
                          
                            <ul class="resp-tabs-list ver_1">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_1">
                                <div>
                                  <?php
                                  foreach($biochemistry_indiv as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                  
                                    <input class="form-check-input chkinput" id="<?= $test->lab_test_id ?>" type="checkbox" data-testname="<?= $test->lab_test_name ?>" data-testprice="<?= $test->rate ?>" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                  
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                <div>
                                  
                                <?php
                                  foreach($biochemistry_grp as $test){ 
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                  <ul class="myUL">
                                    <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span></div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                </div>
                                <?php
                                  }
                                ?>
                                
                                </div>
                                
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>
                <div>
                <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_2">
                            <ul class="resp-tabs-list ver_2">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_2">
                                <div>
                                  <?php
                                    foreach($pathology_indiv as $test){                                    
                                    ?>
                                  <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                      <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                      <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                    
                                  </div>
                                  <?php
                                    }
                                  ?>
                                </div>
                                <div>
                                <?php
                                  foreach($pathology_grp as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                  <ul class="myUL">
                                  <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span></div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>
                <div>
                <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_3">
                            <ul class="resp-tabs-list ver_3">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_3">
                                <div>
                                <?php
                                  foreach($hematology_indiv as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                  
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                  
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                <div>
                                <?php
                                  foreach($hematology_grp as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                <ul class="myUL">
                                  <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span></div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                  
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>

                <div>
                <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_4">
                            <ul class="resp-tabs-list ver_4">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_4">
                                <div>
                                  <?php
                                    foreach($microbiology_indiv as $test){                                    
                                    ?>
                                  <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                    
                                      <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                      <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                    
                                  </div>
                                  <?php
                                    }
                                  ?>
                                </div>
                                <div>
                                <?php
                                  foreach($microbiology_grp as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                  <ul class="myUL">
                                    <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span></div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>

                <div>
                <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_5">
                            <ul class="resp-tabs-list ver_5">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_5">
                                <div>
                                  <?php
                                    foreach($mxtest_indiv as $test){                                    
                                    ?>
                                  <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                    
                                      <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                      <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                    
                                  </div>
                                  <?php
                                    }
                                  ?>
                                </div>
                                <div>
                                <?php
                                  foreach($mxtest_grp as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                <ul class="myUL">
                                  <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span></div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>

                <div>
                <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_6">
                            <ul class="resp-tabs-list ver_6">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_6">
                                <div>
                                  <?php
                                    foreach($semen_analysis_indiv as $test){                                    
                                    ?>
                                  <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                    
                                      <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                      <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                    
                                  </div>
                                  <?php
                                    }
                                  ?>
                                </div>
                                <div>
                                <?php
                                  foreach($semen_analysis_grp as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                <ul class="myUL">
                                  <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span><div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>

                <div>
                <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_7">
                            <ul class="resp-tabs-list ver_7">
                                <li>Individual (T)</li>
                                <li>Group (G)</li>
                            </ul>
                            <div class="resp-tabs-container ver_7">
                                <div>
                                  <?php
                                    foreach($serology_indiv as $test){                                    
                                    ?>
                                  <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                    
                                      <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                      <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span>
                                    
                                  </div>
                                  <?php
                                    }
                                  ?>
                                </div>
                                <div>
                                <?php
                                  foreach($serology_grp as $test){                                    
                                  ?>
                                <div class="col-lg-6 col-md-6 col-sm-12 form-check">
                                <ul class="myUL">
                                  <li><div class="caret" style="display: inline-table;border-top: hidden;margin-left: 0px;border-left: 0px">
                                    <input class="form-check-input" type="checkbox" value="<?= $test->lab_test_id ?>">
                                    <?= $test->lab_test_name." - " ?> <span style="color:#18a4d9;">&#8377; <?= $test->rate ?></span></div>
                                    <?php
                                    $grp_info  = $grptest_xml->xpath('Tests[Subgpname = "'.$test->lab_test_name.'"]');
                                    if(!empty($grp_info)){
                                    ?>
                                        <ul class="nested">
                                        <?php
                                          foreach($grp_info as $info){ 
                                        ?>
                                          <li><?= ' - '.$info->lab_test_name ?></li>
                                        <?php
                                          }
                                        ?>
                                        </ul>
                                    <?php
                                    }
                                    ?>
                                    </li>
                                  </ul>
                                </div>
                                <?php
                                  }
                                ?>
                                </div>
                                
                            </div>
                        </div>
                    </p>
                    <p>&nbsp;</p>
                </div>
            </div>
        </div>
        
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

<!-- Image of location/map -->
<!-- <img src="/w3images/map.jpg" class="w3-image w3-greyscale-min" style="width:100%"> -->

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p>Developed By <a href="#myPage" >PreethiLabs/a></p>
</footer>


<script>  
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
<script src="js/custom.js"></script>
<script>
var toggler = document.getElementsByClassName("caret");
var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener("click", function() { 
    this.parentElement.querySelector(".nested").classList.toggle("active");
    this.classList.toggle("caret-down");
  });
}
</script>


</body>
</html>
