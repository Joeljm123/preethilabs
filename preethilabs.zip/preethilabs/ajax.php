<?php
require_once "phpmailer/class.phpmailer.php";

if($_GET['pid'] == 1)
{

    $mail = new PHPMailer();

    $message =  '';


    $mail->Subject =  "New Booking";

    $mail->MsgHTML($message);
    $mail->SetFrom("manjooranjoel@gmail.com", "Preethilabs");
    $mail->AddAddress("manjooranjoel@gmail.com");
    $mail->Send();

}

?>